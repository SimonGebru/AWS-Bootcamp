export const handler = async (event) => {
    console.log("Event:", event);
  
    // 1) Hämta HTTP-metod från eventet
    const method =
      event?.requestContext?.http?.method ?? // när man kör via Lambda Function URL
      event?.httpMethod ??                   // när man kör via API Gateway
      "UNKNOWN";                             // fallback om inget finns
  
    // 2) Returnera metoden som text
    return {
      statusCode: 200,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
      body: method,
    };
  };